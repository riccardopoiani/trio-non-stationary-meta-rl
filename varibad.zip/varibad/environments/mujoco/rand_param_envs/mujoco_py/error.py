class Error(Exception):
    pass


class MujocoDependencyError(Error):
    pass
