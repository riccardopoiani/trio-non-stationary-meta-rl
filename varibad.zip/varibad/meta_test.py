import argparse
import os
import pickle
import warnings

import torch

# get configs
from config import golf_varibad
from config.mujoco import \
    args_cheetah_vel_varibad, args_ant_goal_varibad
from utils.sequences.sequences_utils import get_cheetah_sequences, get_ant_goal_sequences, get_golf_sequences

from utils import evaluation as utl_eval


def meta_test_sequence(args, policy, ret_rms, encoder, num_test_processes, task_len,
                       task_prior_sequence, boundaries_max, boundaries_min, has_done):
    returns_per_task = utl_eval.meta_test_sequence(args=args,
                                                   policy=policy,
                                                   ret_rms=ret_rms,
                                                   encoder=encoder,
                                                   num_test_processes=num_test_processes,
                                                   task_len=task_len,
                                                   task_prior_sequence=task_prior_sequence,
                                                   boundaries_min=boundaries_min,
                                                   boundaries_max=boundaries_max,
                                                   has_done=has_done
                                                   )
    return returns_per_task


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--env-type', default='ant_goal_varibad')

    parser.add_argument('--input-main-folder', required=True,
                        help="folder that contains the trained policies. The code assumes that the given folder"
                             "will contain x folders, each of which will contain the following: "
                             "encoder.pt, policy.pt, reward_decoder.pt, env_rew_rms.pkl."
                             "These models and information are stored when the policy is being trained.")
    parser.add_argument('--output', required=True, help="folder where to store results")
    parser.add_argument('--noise-seq-var', required=True, type=float,
                        help="Noise variance that will be applied when sampling tasks from the target sequence")
    parser.add_argument('--task-len', required=True, type=int, help="4 for minigolf, 1 for MuJoCo")
    parser.add_argument('--num-test-processes', type=int, required=True, help="use 50 to reproduce results")
    parser.add_argument('--has-done', type=int, required=True,
                        help="True if the policy uses done signal (True for golf and ant, false for cheetah")

    args, rest_args = parser.parse_known_args()
    env = args.env_type
    input_main_folder = args.input_main_folder
    output_folder = args.output
    noise_seq_std = args.noise_seq_var ** (1 / 2)
    task_len = args.task_len
    has_done = True if args.has_done != 0 else False
    num_test_processes = args.num_test_processes

    # --- GridWorld ---

    # --- MUJOCO ---

    # - AntGoal -
    if env == 'ant_goal_varibad':
        args = args_ant_goal_varibad.get_args(rest_args)
        prior_sequences = get_ant_goal_sequences(std=noise_seq_std)
        boundaries_max = torch.tensor([3.0, 3.0])
        boundaries_min = torch.tensor([-3.0, -3.0])
    # - CheetahVel -
    elif env == 'cheetah_vel_varibad':
        args = args_cheetah_vel_varibad.get_args(rest_args)
        prior_sequences = get_cheetah_sequences(std=noise_seq_std)
        boundaries_min = torch.tensor([0.0])
        boundaries_max = torch.tensor([1.5])
    elif env == 'golf_varibad':
        args = golf_varibad.get_args(rest_args)
        prior_sequences = get_golf_sequences(std=noise_seq_std)
        boundaries_min = torch.tensor([0.01])
        boundaries_max = torch.tensor([2.0])
    else:
        raise NotImplemented()

    # warning for deterministic execution
    if args.deterministic_execution:
        print('Envoking deterministic code execution.')
        if torch.backends.cudnn.enabled:
            warnings.warn('Running with deterministic CUDNN.')
        if args.num_processes > 1:
            raise RuntimeError('If you want fully deterministic code, run it with num_processes=1.'
                               'Warning: This will slow things down and might break A2C if '
                               'policy_num_steps < env._max_episode_steps.')

    # clean up arguments
    if hasattr(args, 'disable_decoder') and args.disable_decoder:
        args.decode_reward = False
        args.decode_state = False
        args.decode_task = False

    if hasattr(args, 'decode_only_past') and args.decode_only_past:
        args.split_batches_by_elbo = True
    # if hasattr(args, 'vae_subsample_decodes') and args.vae_subsample_decodes:
    #     args.split_batches_by_elbo = True

    # begin training (loop through all passed seeds)
    seed_list = [args.seed] if isinstance(args.seed, int) else args.seed
    for seed in seed_list:

        all_files = os.listdir(input_main_folder)

        args.seed = seed
        for seq_idx, sequence in enumerate(prior_sequences):

            all_returns = []
            for idx, file in enumerate(all_files):
                print("Meta test {}".format(idx))

                policy = torch.load(input_main_folder + file + "/policy.pt")
                encoder = torch.load(input_main_folder + file + "/encoder.pt")

                with open(input_main_folder + file + "/env_rew_rms.pkl", 'rb') as f:
                    ret_rms = pickle.load(f)
                curr_returns = meta_test_sequence(args=args,
                                                  policy=policy,
                                                  encoder=encoder,
                                                  ret_rms=ret_rms,
                                                  num_test_processes=num_test_processes,
                                                  task_len=task_len,
                                                  task_prior_sequence=sequence,
                                                  boundaries_min=boundaries_min,
                                                  boundaries_max=boundaries_max,
                                                  has_done=has_done
                                                  )
                all_returns.append(curr_returns)

            with open("{}results_varibad_seq{}.pkl".format(output_folder, seq_idx), "wb") as output:
                pickle.dump(all_returns, output)


if __name__ == '__main__':
    main()
