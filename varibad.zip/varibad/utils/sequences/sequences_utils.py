import torch
import numpy as np


################## GOLF SEQUENCES #####################

def f_linear_golf(x):
    return 1 + (x - 20) / 10


def f_sin_golf(x, freq=0.1, offset=-0.7, a=-0.2):
    t = a * np.sin(freq * x) + offset
    return t


def f_sawtooth_golf(x, period=50):
    saw_tooth = 2 * (x / period - np.floor(0.5 + x / period))
    saw_tooth = (-0.6 - (-1)) / (1 - (-1)) * (saw_tooth - 1) - 0.6
    return saw_tooth + 0.3


def get_golf_sequences(std):
    sin = get_golf_sin_sequence(seq_len=100, std=std)
    sawtooth = get_golf_sawtooth_sequence(seq_len=110, std=std)
    tan = get_golf_tan_sequence(seq_len=50, std=std)

    return [sin, sawtooth, tan]


def get_golf_sin_sequence(seq_len, std):
    prior_seq = []
    for idx in range(0, seq_len):
        friction = f_sin_golf(idx)
        # friction = (2 - 0.01) / (1 - (-1)) * (friction - 1) + 2
        prior_seq.append(torch.tensor([[friction], [std ** 2]], dtype=torch.float32))

    return prior_seq


def get_golf_sawtooth_sequence(seq_len, std):
    prior_seq = []
    for idx in range(0, seq_len):
        friction = f_sawtooth_golf(idx)
        # friction = (2 - 0.01) / (1 - (-1)) * (friction - 1) + 2
        prior_seq.append(torch.tensor([[friction], [std ** 2]], dtype=torch.float32))

    return prior_seq


def get_golf_tan_sequence(seq_len, std):
    prior_seq = []
    for idx in range(0, seq_len):
        friction = np.tanh(idx - 5) + 0.2
        # friction = (2 - 0.01) / (1 - (-1)) * (friction - 1) + 2
        prior_seq.append(torch.tensor([[friction], [std ** 2]], dtype=torch.float32))

    return prior_seq


################## CHEETAH VEL SEQUENCES #####################

def f_tan(x):
    if x <= 30:
        return -0.8
    elif x <= 60:
        return 0.5
    else:
        return 0


def f_sin_tan(x):
    x = x + 5
    return (-np.tanh(x / 16) + (np.sin(x / 2) / (x / 16))) / 4


def get_cheetah_sequences(std):
    sin_tan = get_sin_tan_sequence(seq_len=100, std=std)
    tan = get_tan_sequence(seq_len=150, std=std)

    return [sin_tan, tan]


def get_sin_tan_sequence(seq_len, std):
    prior_seq = []
    for idx in range(0, seq_len):
        vel = f_sin_tan(idx)
        # vel = (1.5 - 0) / (1 - (-1)) * (vel - 1) + 1.5
        prior_seq.append(torch.tensor([[vel], [std ** 2]], dtype=torch.float32))

    return prior_seq


def get_tan_sequence(seq_len, std):
    prior_seq = []
    for idx in range(0, seq_len):
        target_vel = f_tan(x=idx)
        # target_vel = (1.5 - 0) / (1 - (-1)) * (target_vel - 1) + 1.5
        prior_seq.append(torch.tensor([[target_vel], [std ** 2]], dtype=torch.float32))

    return prior_seq


################## ANT GOAL SEQUENCES #####################


def f_radius(theta, latent_dim):
    if latent_dim == 0:
        return np.cos(theta)
    else:
        return np.sin(theta)


def root_theta(x):
    x = 16 * x
    x = x + 5
    return (x ** (1 / 2)) * 2 * np.pi / 15


def get_ant_goal_sequences(std):
    circuit = get_circuit_sequence(seq_len=100, std=std)
    step = get_ant_step_sequence(seq_len=30, std=std)

    return [circuit, step]


def get_circuit_sequence(seq_len, std):
    latent_dim = 2
    prior_seq = []
    for idx in range(seq_len):
        p_mean = []
        p_var = []
        theta = root_theta(idx)
        for dim in range(latent_dim):
            p_mean.append(f_radius(theta=theta, latent_dim=dim))
            p_var.append(std ** 2)

        # p_mean = (3 - (-3)) / (1 - (-1)) * (np.array(p_mean) - 1) + 3
        # p_mean = p_mean.tolist()
        prior_seq.append(torch.tensor([p_mean, p_var], dtype=torch.float32))

    return prior_seq


def get_ant_step_sequence(seq_len, std):
    latent_dim = 2
    prior_seq = []
    for idx in range(seq_len):
        p_mean = []
        p_var = []
        theta = np.pi / 4 if idx <= 20 else np.pi * (5 / 4)
        for dim in range(latent_dim):
            p_mean.append(f_radius(theta=theta, latent_dim=dim))
            p_var.append(std ** 2)

        # p_mean = (3 - (-3)) / (1 - (-1)) * (np.array(p_mean) - 1) + 3
        # p_mean = p_mean.tolist()
        prior_seq.append(torch.tensor([p_mean, p_var], dtype=torch.float32))

    return prior_seq
