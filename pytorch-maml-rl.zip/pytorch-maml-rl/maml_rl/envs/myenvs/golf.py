from numbers import Number

import gym
from gym import spaces
from gym.utils import seeding
import numpy as np
import math as m
from scipy.stats import norm

"""
Minigolf task.
References
----------
  - Penner, A. R. "The physics of putting." Canadian Journal of Physics 80.2 (2002): 83-96.
"""


class Golf(gym.Env):
    metadata = {'render.modes': ['human']}

    def __init__(self, task={}, low=0.01, high=2):
        super(Golf, self).__init__()

        self.horizon = 20
        self.gamma = 0.99

        self.min_pos = 0.0
        self.max_pos = 20.0
        self.min_action = 1e-5
        self.max_action = 10.0
        self.putter_length = 1.0  # [0.7:1.0]
        self.low = low
        self.high = high
        if task.get('friction') is not None:
            self.friction = task.get('friction')
        else:
            self.friction = None
        self.hole_size = 0.10  # [0.10:0.15]
        self.sigma_noise = 0.3
        self.ball_radius = 0.02135
        self.min_variance = 1e-2  # Minimum variance for computing the densities
        self._task = task

        # gym attributes
        self.viewer = None
        low = np.array([self.min_pos])
        high = np.array([self.max_pos])
        self.action_space = spaces.Box(low=self.min_action,
                                       high=self.max_action,
                                       shape=(1,))
        self.observation_space = spaces.Box(low=low, high=high)

        # initialize state
        self.seed()
        self.reset()

    def sample_tasks(self, num_tasks):
        fs = self.np_random.uniform(self.low, self.high, size=(num_tasks,))
        tasks = [{'friction': f} for f in fs]
        return tasks

    def get_task_from_dist(self, friction_mu, friction_std):
        # friction_mu = [((2 - 0.01) / (1 - (-1))) * (mu - 1) + 2 for mu in friction_mu]
        assert len(friction_mu) == len(friction_std), "Error while sampling tasks from the given distribution"

        tasks = []
        for f_mu, f_std in zip(friction_mu, friction_std):
            f = self.np_random.normal(loc=f_mu, scale=f_std, size=(1,))[0]
            f = ((2 - 0.01) / (1 - (-1))) * (f - 1) + 2
            tasks.append({'friction': f})

        return tasks

    def reset_task(self, task):
        self._task = task
        self.friction = task['friction']

    def step(self, action, render=False):
        action = np.clip(action, self.min_action, self.max_action / 2)

        noise = 10
        while abs(noise) > 1:
            noise = self.np_random.randn() * self.sigma_noise
        u = action * self.putter_length * (1 + noise)

        v_min = np.sqrt(10 / 7 * self.friction * 9.81 * self.state)
        v_max = np.sqrt((2 * self.hole_size - self.ball_radius) ** 2 * (9.81 / (2 * self.ball_radius)) + v_min ** 2)

        deceleration = 5 / 7 * self.friction * 9.81

        t = u / deceleration
        xn = self.state - u * t + 0.5 * deceleration * t ** 2

        reward = 0
        done = True
        if u < v_min:
            reward = -1
            done = False
        elif u > v_max:
            reward = -100

        self.state = xn

        return self.get_state(), float(reward), done, {'task': self._task}

    def reset(self, state=None):
        if state is None:
            self.state = np.array([self.np_random.uniform(low=self.min_pos,
                                                          high=self.max_pos)])
        else:
            self.state = np.array(state)

        return self.get_state()

    def get_state(self):
        return np.array(self.state)

    def render(self, mode='human'):
        raise NotImplementedError

    def seed(self, seed=None):
        self.np_random, seed = seeding.np_random(seed)
        return [seed]

    def close(self):
        pass
