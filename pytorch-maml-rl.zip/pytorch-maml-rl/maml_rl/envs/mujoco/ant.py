import numpy as np

from gym.envs.mujoco import mujoco_env


class AntPosEnv(mujoco_env.MujocoEnv):

    def __init__(self, task={}, low=-3.0, high=3.0):
        self._task = task
        self.low = low
        self.high = high

        self._goal_pos = task.get('position', np.zeros((2,), dtype=np.float32))
        self._action_scaling = None
        mujoco_env.MujocoEnv.__init__(self, model_path='ant.xml', frame_skip=5)

    @property
    def action_scaling(self):
        if (not hasattr(self, 'action_space')) or (self.action_space is None):
            return 1.0
        if self._action_scaling is None:
            lb, ub = self.action_space.low, self.action_space.high
            self._action_scaling = 0.5 * (ub - lb)
        return self._action_scaling

    def step(self, action):
        self.do_simulation(action, self.frame_skip)
        xposafter = np.array(self.get_body_com("torso"))

        goal_reward = -np.sum(np.abs(xposafter[:2] - self._goal_pos))  # make it happy, not suicidal

        ctrl_cost = 0.1 * np.square(action).sum()
        contact_cost = 0.5 * 1e-3 * np.sum(
            np.square(np.clip(self.sim.data.cfrc_ext, -1, 1)))
        survive_reward = 0.0
        reward = goal_reward - ctrl_cost - contact_cost + survive_reward
        state = self.state_vector()
        done = False
        ob = self._get_obs()
        return ob, reward, done, dict(
            goal_forward=goal_reward,
            reward_ctrl=-ctrl_cost,
            reward_contact=-contact_cost,
            reward_survive=survive_reward,
            task=self._task
        )

    def _get_obs(self):
        return np.concatenate([
            self.sim.data.qpos.flat,
            self.sim.data.qvel.flat,
            np.clip(self.sim.data.cfrc_ext, -1, 1).flat,
        ]).astype(np.float32)

    def sample_tasks(self, num_tasks):
        positions = self.np_random.uniform(self.low, self.high, size=(num_tasks, 2))
        tasks = [{'position': position} for position in positions]
        return tasks

    def reset_task(self, task):
        self._task = task
        self._goal_pos = task['position']

    def reset_model(self):
        qpos = self.init_qpos + self.np_random.uniform(size=self.model.nq, low=-.1, high=.1)
        qvel = self.init_qvel + self.np_random.randn(self.model.nv) * .1
        self.set_state(qpos, qvel)
        ob = self._get_obs()
        return ob

    def get_task_from_dist(self, x_mean, y_mean, x_std, y_std):
        # x_mean = [((3 - (-3)) / (1 - (-1))) * (mu - 1) + 3 for mu in x_mean]
        # y_mean = [((3 - (-3)) / (1 - (-1))) * (mu - 1) + 3 for mu in y_mean]

        tasks = []
        for curr_x_mu, curr_y_mu, curr_x_std, curr_y_std in zip(x_mean, y_mean, x_std, y_std):
            x = self.np_random.normal(loc=curr_x_mu, scale=curr_x_std, size=(1,))[0]
            y = self.np_random.normal(loc=curr_y_mu, scale=curr_y_std, size=(1,))[0]
            x = ((3 - (-3)) / (1 - (-1))) * (x - 1) + 3
            y = ((3 - (-3)) / (1 - (-1))) * (y - 1) + 3
            tasks.append({'position': np.array([x, y])})

        return tasks