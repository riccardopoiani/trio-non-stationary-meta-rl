import numpy as np


############################### Sequence to be meta-tested ###############################

def get_sequence_num(env_name):
    if env_name == 'golf-v0':
        return 3
    elif env_name == 'HalfCheetahVel-v2':
        return 2
    elif env_name == 'AntPos-v1':
        return 2
    else:
        raise NotImplemented("No env with this name has defined sequences")


def get_sequence(env_name, seq_idx, std):
    if env_name == 'golf-v0':
        return get_golf_sequence(seq_idx, std)
    elif env_name == 'HalfCheetahVel-v2':
        return get_cheetah_sequence(seq_idx, std)
    elif env_name == 'AntPos-v1':
        return get_antgoal_sequence(seq_idx, std)
    else:
        raise NotImplemented("No env with this name has defined sequences")


############################### Ant sequences ###############################
def get_antgoal_sequence(seq_idx, std):
    if seq_idx == 0:
        seq_len = 100
        seq_dist_kwargs = []
        for idx in range(seq_len):
            theta = root_theta(16 * idx)
            d1 = f_radius(theta=theta, latent_dim=0)
            d2 = f_radius(theta=theta, latent_dim=1)
            seq_dist_kwargs.append({'x_mean': [d1],
                                    'y_mean': [d2],
                                    'x_std': [std],
                                    'y_std': [std]})
    elif seq_idx == 1:
        seq_len = 30
        seq_dist_kwargs = []
        for idx in range(seq_len):
            theta = np.pi / 4 if idx <= 20 else np.pi * (5 / 4)
            d1 = f_radius(theta=theta, latent_dim=0)
            d2 = f_radius(theta=theta, latent_dim=1)
            seq_dist_kwargs.append({'x_mean': [d1],
                                    'y_mean': [d2],
                                    'x_std': [std],
                                    'y_std': [std]})
    else:
        raise NotImplemented("Only sequences in {0, 1, 2} are valid indexes for Ant")

    return seq_len, seq_dist_kwargs


############################### Cheetah sequences ###############################

def get_cheetah_sequence(seq_idx, std):
    if seq_idx == 0:
        seq_len = 100
        seq_dist_kwargs = []
        for idx in range(0, seq_len):
            speed = f_sin_tan_cheetah(x=idx)
            seq_dist_kwargs.append({'speed_mu': [speed],
                                    'speed_std': [std]})
    elif seq_idx == 1:
        seq_len = 150
        seq_dist_kwargs = []
        for idx in range(0, seq_len):
            speed = f_tan_cheetah(x=idx)
            seq_dist_kwargs.append({'speed_mu': [speed],
                                    'speed_std': [std]})
    else:
        raise NotImplemented("Only sequences in {0, 1} are valid indexes for Cheetah")

    return seq_len, seq_dist_kwargs


############################### Golf sequences ###############################

def get_golf_sequence(seq_idx, std):
    if seq_idx == 0:
        seq_len = 100
        seq_dist_kwargs = []
        for idx in range(0, seq_len):
            friction = f_sin(idx)
            seq_dist_kwargs.append({'friction_mu': [friction],
                                    'friction_std': [std]})
    elif seq_idx == 1:
        seq_len = 110

        seq_dist_kwargs = []
        for idx in range(0, seq_len):
            friction = f_sawtooth(idx)
            seq_dist_kwargs.append({'friction_mu': [friction],
                                    'friction_std': [std]})
    elif seq_idx == 2:
        seq_len = 50

        seq_dist_kwargs = []
        for idx in range(0, seq_len):
            friction = np.tanh(idx - 5) + 0.2
            seq_dist_kwargs.append({'friction_mu': [friction],
                                    'friction_std': [std]})
    else:
        raise NotImplemented("Only sequences in [0,1] are valid indexes for gauss env")

    return seq_len, seq_dist_kwargs


############################### Sequence utils - Ant goal ###############################

def f_radius(theta, latent_dim):
    if latent_dim == 0:
        return np.cos(theta)
    else:
        return np.sin(theta)


def root_theta(x):
    x = x + 5
    return (x ** (1 / 2)) * 2 * np.pi / 15


############################### Sequence utils - Cheetah ###############################
def f_tan_cheetah(x):
    if x <= 30:
        return -0.8
    elif x <= 60:
        return 0.5
    else:
        return 0


def f_sin_tan_cheetah(x):
    x = x + 5
    return (-np.tanh(x / 16) + (np.sin(x / 2) / (x / 16))) / 4


############################### Sequence utils - Golf ###############################
def f_sin(x, freq=0.1, offset=-0.7, a=-0.2):
    t = a * np.sin(freq * x) + offset
    return t


def f_sawtooth(x, period=50):
    saw_tooth = 2 * (x / period - np.floor(0.5 + x / period))
    saw_tooth = (-0.6 - (-1)) / (1 - (-1)) * (saw_tooth - 1) - 0.6
    return saw_tooth + 0.3
