import maml_rl.envs
import gym
import torch
import json
import numpy as np

from maml_rl.baseline import LinearFeatureBaseline
from maml_rl.samplers import MultiTaskSampler
from maml_rl.utils.helpers import get_policy_for_env, get_input_size
from maml_rl.utils.reinforcement_learning import get_returns
from maml_rl.utils.sequences import get_sequence, get_sequence_num


def main(args, run_id):
    with open(args.config, 'r') as f:
        print("Opening config: {}".format(f))
        config = json.load(f)

    if args.seed is not None:
        torch.manual_seed(args.seed)
        torch.cuda.manual_seed_all(args.seed)

    env = gym.make(config['env-name'], **config['env-kwargs'])
    env.close()

    # Policy
    policy = get_policy_for_env(env,
                                hidden_sizes=config['hidden-sizes'],
                                nonlinearity=config['nonlinearity'])
    with open(args.policy, 'rb') as f:
        state_dict = torch.load(f, map_location=torch.device(args.device))
        policy.load_state_dict(state_dict)
    policy.share_memory()

    # Baseline
    baseline = LinearFeatureBaseline(get_input_size(env))

    # Sampler
    # Run with fast-batch-size = num-test-processes
    sampler = MultiTaskSampler(config['env-name'],
                               env_kwargs=config['env-kwargs'],
                               batch_size=args.fast_batch_size,
                               policy=policy,
                               baseline=baseline,
                               env=env,
                               seed=args.seed,
                               num_workers=args.num_workers)

    num_seq = get_sequence_num(env_name=config['env-name'])

    for seq_idx in range(num_seq):
        print("Sequence number {}".format(seq_idx))
        # Run validation on the current sequence
        logs = {'tasks': []}
        train_returns, valid_returns = [], []
        seq_len, seq_dist_kwargs = get_sequence(env_name=config['env-name'], std=args.seq_std, seq_idx=seq_idx)

        for dist_kwargs in seq_dist_kwargs:
            tasks = sampler.sample_tasks_from_dist(dist_kwargs=dist_kwargs)  # sample tasks from the given dist.
            train_episodes, valid_episodes = sampler.sample(tasks,
                                                            num_steps=args.num_steps,
                                                            fast_lr=config['fast-lr'],
                                                            gamma=config['gamma'],
                                                            gae_lambda=config['gae-lambda'],
                                                            device=args.device)  # run the tasks and collect the rewards

            logs['tasks'].extend(tasks)
            for k in range(args.num_steps):
                train_returns.append(get_returns(train_episodes[k]))

            valid_returns.append(get_returns(valid_episodes))

        logs['train_returns'] = np.concatenate(train_returns, axis=0)
        logs['valid_returns'] = np.concatenate(valid_returns, axis=0)

        f_name = args.output + "/policy_" + str(run_id) + "_seq_" + str(seq_idx)
        with open(f_name, 'wb') as f:
            np.savez(f, **logs)


if __name__ == '__main__':
    import argparse
    import os
    import multiprocessing as mp

    parser = argparse.ArgumentParser(description='Reinforcement learning with '
                                                 'Model-Agnostic Meta-Learning (MAML) - Test')

    parser.add_argument('--input-main-folder', required=True)

    # Evaluation
    evaluation = parser.add_argument_group('Evaluation')
    evaluation.add_argument('--num-batches', type=int, default=1,
                            help='number of batches (default: 10)')
    evaluation.add_argument('--meta-batch-size', type=int, default=1,
                            help='number of tasks per batch (default: 40)')
    evaluation.add_argument('--num-steps', type=int, default=1)
    evaluation.add_argument('--fast-batch-size', type=int, default=50)

    # Miscellaneous
    misc = parser.add_argument_group('Miscellaneous')
    misc.add_argument('--output', type=str, required=True,
                      help='name of the output folder (default: maml)')
    misc.add_argument('--seed', type=int, default=None,
                      help='random seed')
    misc.add_argument('--num-workers', type=int, default=mp.cpu_count() - 1,
                      help='number of workers for trajectories sampling (default: '
                           '{0})'.format(mp.cpu_count() - 1))
    misc.add_argument('--use-cuda', action='store_true',
                      help='use cuda (default: false, use cpu). WARNING: Full upport for cuda '
                           'is not guaranteed. Using CPU is encouraged.')

    # Sequence infos
    seq_args = parser.add_argument_group('Sequences')
    seq_args.add_argument('--seq-std', type=float, required=True, help="Standard deviation of the task in the sequence")

    args = parser.parse_args()
    args.device = ('cuda' if (torch.cuda.is_available()
                              and args.use_cuda) else 'cpu')

    d = os.listdir(args.input_main_folder)
    i = 0
    for f in d:
        print("Evaluating policy number {}".format(i))
        args.policy = args.input_main_folder + f + '/policy.th'
        args.config = args.input_main_folder + f + '/config.json'
        main(args, run_id=i)
        i += 1
