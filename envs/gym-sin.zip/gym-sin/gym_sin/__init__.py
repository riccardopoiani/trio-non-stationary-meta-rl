from gym.envs.registration import register

register(
    id='gauss-v0',
    entry_point='gym_sin.envs:GaussEnv',
    max_episode_steps=100
)

register(
    id="gaussexplore-v0",
    entry_point='gym_sin.envs:GaussExploreEnv',
    max_episode_steps=10
)

register(
    id='minigolf-v0',
    entry_point='gym_sin.envs:MiniGolf',
    max_episode_steps=20
)

register(
    id='gridworld-v0',
    entry_point='gym_sin.envs:GridWorld',
    max_episode_steps=30
)
