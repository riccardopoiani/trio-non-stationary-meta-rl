import gym
import numpy as np
from gym import spaces
from gym.utils import seeding


class GaussEnv(gym.Env):
    metadata = {'render.modes': ['human']}

    def __init__(self, amplitude=1, mean=0, std=1, noise_std=0.001, min_x=-100, max_x=100, scale_reward=True):
        super(GaussEnv, self).__init__()

        # Env. parameters
        self.a = amplitude
        self.mean = mean
        self.std = std
        self.noise_std = noise_std

        self.min_x = min_x
        self.max_x = max_x

        self.state = 0  # There is a single state

        self.action_space = spaces.Box(low=-1., high=1., shape=(1,), dtype="float32")
        self.observation_space = spaces.Box(low=np.array([0]), high=np.array([0]))

        self.scale_reward = scale_reward

    def set_latent(self, amplitude=1, mean=0, std=1, noise_std=0.001, min_x=-100, max_x=100, scale_reward=True):
        self.a = amplitude
        self.mean = mean
        self.std = std
        self.noise_std = noise_std
        self.min_x = min_x
        self.max_x = max_x
        self.scale_reward = scale_reward

    def reset(self):
        self.state = 0
        return np.array([self.state])

    def get_state(self):
        return np.array([self.state])

    def step(self, action):
        # Rescale action
        action = (self.max_x - self.min_x) / (1 - (-1)) * (action - 1) + self.max_x

        if action < self.min_x:
            action = np.array([self.min_x])
        elif action > self.max_x:
            action = np.array([self.max_x])

        noise = np.random.normal(loc=0, scale=self.noise_std, size=1)
        reward = self.a * np.exp(-((action - self.mean) ** 2) / (self.std ** 2)) + noise
        reward = reward[0]

        log = {'noise': noise, 'action': action, 'amp': self.a, 'reward': reward}

        if self.scale_reward:
            reward = reward / self.a

        return np.array([self.state]), reward, False, log

    def render(self, mode='human'):
        raise NotImplementedError

    def seed(self, seed=None):
        self.np_random, seed = seeding.np_random(seed)
        return [seed]

    def close(self):
        pass
