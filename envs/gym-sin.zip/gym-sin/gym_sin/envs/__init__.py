from gym_sin.envs.sinenv import SinEnv
from gym_sin.envs.gaussenv import GaussEnv
from gym_sin.envs.gaussexploreenv import GaussExploreEnv
from gym_sin.envs.minigolfenv import MiniGolf
from gym_sin.envs.gridworldenv import GridWorld
