import gym
import numpy as np
from gym import spaces
from gym.utils import seeding


class SinEnv(gym.Env):
    metadata = {'render.modes': ['human']}

    def __init__(self, amplitude=1, phase=0, frequency=1, noise_std=0.1, min_x=-5, max_x=5, scale_reward=True):
        super(SinEnv, self).__init__()

        # Env. parameters
        self.a = amplitude
        self.p = phase
        self.f = frequency
        self.noise_std = noise_std

        self.min_x = min_x
        self.max_x = max_x

        self.state = 0  # There is a single state

        self.action_space = spaces.Box(low=np.array([-5]), high=np.array([5]))
        self.observation_space = spaces.Box(low=np.array([0]), high=np.array([0]))

        self.scale_reward = scale_reward

    def reset(self):
        self.state = 0
        return np.array([self.state])

    def get_state(self):
        return np.array([self.state])

    def step(self, action):
        if action < self.min_x or action > self.max_x:
            log = {'noise': 0, 'action': action, 'amp': self.a, 'reward': 0}
            return np.array([self.state]), 0, False, log

        noise = np.random.normal(loc=0, scale=self.noise_std, size=1)
        reward = self.a * np.sin(self.f * action + self.p) + noise
        reward = reward[0]

        log = {'noise': noise, 'action': action, 'amp': self.a, 'reward': reward}

        if self.scale_reward:
            reward = reward / self.a

        return np.array([self.state]), reward, False, log

    def render(self, mode='human'):
        raise NotImplementedError

    def seed(self, seed=None):
        self.np_random, seed = seeding.np_random(seed)
        return [seed]

    def close(self):
        pass
