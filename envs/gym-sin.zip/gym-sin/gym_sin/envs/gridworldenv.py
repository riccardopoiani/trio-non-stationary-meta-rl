import gym
import numpy as np
from gym import spaces
from gym.utils import seeding


class GridWorld(gym.Env):
    """
    GridWorld continuous environment

    - State (x, y, direction of the agent). X and Y are continuous in (-size/2, size/2), while direction is
    an angle in (0, 2*Pi)
    - Action (move forward, rotate): agent first rotate toward that direction and than it makes a step toward
    that direction.
    Move forward space is continuous in [0, 1]: the agent takes a step toward that direction whose length depends on
    the intensity of the action. The bigger the step, the bigger the noise in the action.
    Rotate space is continuous in [-Pi/2, Pi/2]. The bigger the rotation, the bigger the noise.
    - Goal (x, y, radius): the agent reaches the goal when it is within a certain radius from the specified position
    - Charge sensors: the agent has sensors that allows him to make the rotation (turn left or right) and move forward
    whose power might be different according to the situation. Charge values are in [0, 1]: a charge of 0 means
    that the agent won't see any result from taking that action, while a charge of 1 means that the sensor is working
    at its best. The value in between affect the range of its corresponding action (i.e. if charge right is 0.5,
    than the possibility of rotating to right will be halved).
    In other words, move forward action range is specified as (0, 1 * charge_capacity), while rotate range
    is specified as (charge_left * (-Pi/2), charge_right * (Pi/2).
    """

    metadata = {'render.modes': ['human']}

    # Action settings
    MAX_FORWARD = 1
    MIN_FORWARD = 0
    MAX_RIGHT = np.pi / 2
    MAX_LEFT = -np.pi / 2

    # Action noise setting
    ROT_NOISE_SCALE = 0.1
    FORWARD_NOISE_SCALE = 0.1

    # Observation settings
    MAX_ANGLE = 2 * np.pi
    MIN_ANGLE = 0

    # Init settings
    MIN_INIT_DISTANCE = 2

    def __init__(self, size, goal_x, goal_y, goal_radius, charge_left, charge_right, charge_forward):
        super(GridWorld, self).__init__()

        # Env. parameters
        self.size = size
        self.goal_x = ((self.size / 2 - (-self.size / 2)) / (1 - (-1))) * (goal_x - 1) + self.size / 2
        self.goal_y = ((self.size / 2 - (-self.size / 2)) / (1 - (-1))) * (goal_y - 1) + self.size / 2
        self.goal_radius = goal_radius

        self.charge_left = ((1 - 0.2) / (1 - (-1))) * (charge_left - 1) + 1
        self.charge_right = ((1 - 0.2) / (1 - (-1))) * (charge_right - 1) + 1
        self.charge_forward = ((1 - 0.5) / (1 - (-1))) * (charge_forward - 1) + 1

        self.state = (0, 0, 0)
        self.max_distance = np.sqrt((size)**2 + (size**2))
        self._init_state()

        high_obs = np.array([
            self.size / 2,
            self.size / 2,
            self.MAX_ANGLE
        ], dtype=np.float32)

        low_obs = np.array([
            -self.size / 2,
            -self.size / 2,
            self.MIN_ANGLE
        ])

        self.observation_space = spaces.Box(low=low_obs, high=high_obs)

        high_act = np.array([
            self.MAX_FORWARD,
            self.MAX_RIGHT,
        ], dtype=np.float32)

        low_act = np.array([
            self.MIN_FORWARD,
            self.MAX_LEFT
        ], dtype=np.float32)

        self.action_space = spaces.Box(low=low_act, high=high_act)

    # UTILITIES

    def set_latent(self, size, goal_x, goal_y, goal_radius, charge_left, charge_right, charge_forward):
        self.size = size
        self.goal_x = ((self.size / 2 - (-self.size / 2)) / (1 - (-1))) * (goal_x - 1) + self.size / 2
        self.goal_y = ((self.size / 2 - (-self.size / 2)) / (1 - (-1))) * (goal_y - 1) + self.size / 2
        self.goal_radius = goal_radius

        self.charge_left = ((1 - 0.2) / (1 - (-1))) * (charge_left - 1) + 1
        self.charge_right = ((1 - 0.2) / (1 - (-1))) * (charge_right - 1) + 1
        self.charge_forward = ((1 - 0.5) / (1 - (-1))) * (charge_forward - 1) + 1

    def _init_state(self):
        not_ok = True

        while not_ok:
            state_x = np.random.uniform(low=-self.size / 2, high=self.size / 2, size=1)[0]
            state_y = np.random.uniform(low=-self.size / 2, high=self.size / 2, size=1)[0]
            direction = np.random.uniform(low=self.MIN_ANGLE, high=self.MAX_ANGLE, size=1)[0]
            self.state = (state_x, state_y, direction)
            not_ok = self._goal_reached()

    def _goal_reached(self):
        d = np.sqrt((self.goal_x - self.state[0]) ** 2 + (self.goal_y - self.state[1]) ** 2)
        return True if d < self.goal_radius else False

    def _rescale_action(self, action):
        # limit action within action bound
        if action[0] > self.MAX_FORWARD:
            action[0] = self.MAX_FORWARD
        elif action[0] < self.MIN_FORWARD:
            action[0] = self.MIN_FORWARD

        if action[1] > self.MAX_RIGHT:
            action[1] = self.MAX_RIGHT
        elif action[1] < self.MAX_LEFT:
            action[1] = self.MAX_LEFT

        # apply charge sensors
        action[0] = action[0] * self.charge_forward
        if action[1] > 0:
            action[1] = action[1] * self.charge_right
        else:
            action[1] = action[1] * self.charge_left

        return action

    def _rotate(self, action):
        # compute direction offset
        rot_noise = self.ROT_NOISE_SCALE * np.abs(action[1] / self.MAX_LEFT)
        noise = np.random.normal(loc=0, scale=rot_noise)
        dir_offset = action[1] + noise

        # compute new direction
        curr_dir = self.state[-1]
        new_dir = curr_dir + dir_offset

        new_dir = np.arctan2(np.sin(new_dir + np.pi), np.cos(new_dir + np.pi)) + np.pi

        if new_dir < self.MIN_ANGLE:
            new_dir = self.MAX_ANGLE + new_dir
        elif new_dir > self.MAX_ANGLE:
            new_dir = new_dir - self.MAX_ANGLE

        assert self.MAX_ANGLE >= new_dir >= self.MIN_ANGLE

        return new_dir

    def _forward(self, action, curr_dir):
        for_noise = self.FORWARD_NOISE_SCALE * np.abs(action[0] / self.MAX_FORWARD)
        noise = np.random.normal(loc=0, scale=for_noise)
        a = action[0] + noise
        new_x = self.state[0] + a * np.cos(curr_dir)
        new_y = self.state[1] + a * np.sin(curr_dir)

        if new_x > self.size / 2:
            new_x = self.size / 2
        elif new_x < -self.size / 2:
            new_x = -self.size / 2

        if new_y > self.size / 2:
            new_y = self.size / 2
        elif new_y < -self.size / 2:
            new_y = -self.size / 2

        return new_x, new_y

    # GYM METHODS

    def reset(self):
        self._init_state()
        while np.sqrt((self.goal_x - self.state[0]) ** 2 + (self.goal_y - self.state[1]) ** 2) < self.MIN_INIT_DISTANCE:
            self._init_state()
        return np.array([self.state])

    def get_state(self):
        return np.array([self.state])

    def step(self, action):
        # Rescale action due to sensor's charge and limit it within the box
        action = self._rescale_action(action)

        # Get rotation offset
        new_dir = self._rotate(action)

        # Apply forward
        new_x, new_y = self._forward(action, new_dir)

        self.state = (new_x, new_y, new_dir)

        done = False
        reward = -np.sqrt((self.goal_x - self.state[0]) ** 2 + (self.goal_y - self.state[1]) ** 2) / self.max_distance
        if self._goal_reached():
            done = True
            reward = 0

        return np.array([self.state]), reward, done, {}

    def render(self, mode='human'):
        raise NotImplementedError

    def seed(self, seed=None):
        self.np_random, seed = seeding.np_random(seed)
        return [seed]

    def close(self):
        pass
